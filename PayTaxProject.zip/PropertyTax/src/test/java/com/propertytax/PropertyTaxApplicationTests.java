package com.propertytax;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PropertyTaxApplicationTests {

	@Test
	void contextLoads() {
	}

}
